<?php
// Imports completar
require_once "../models/AvistamientosMeteoritosModel.php";
require_once "../views/ImpactoView.php";
require_once "../views/ResultadoBusquedaMeteoritoView.php";
class AvistamientosController {
    private $modelo;
    private $vistaImpacto;
    private $vistaResultadoBusqueda;
    
    public function __construct() {
       $modelo = new AvistamientosMeteroritosModel();
       $vistaImpacto = new ImpactoView();
       $vistaResultadoBusqueda = new ResultadoBusquedaMeteoritoView();
    }

    public function buscar($nombreMeteorito) {

        // 1 Obtener resultados desde el modelo 
        $this->modelo->buscarMeteoritos($nombreMeteorito);

        // 2 Mostrar la vista con los resultados
        $this->vistaResultadoBusqueda->render();

    }
    public function obtenerImpacto($tam,$velocidad){
        //Completar
        $this->modelo->buscarMeteoritos($nombreMeteorito);
    }
}
