<?php

Interface ViewInterface {

 public function render($datos);
 


}
