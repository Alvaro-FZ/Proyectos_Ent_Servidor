<?php
require_once "controllers/AvistamientosController.php";
require_once "views/MeteoritoBusquedaView.php";

// Instanciar controlador y vista
$controller = new AvistamientosController();
$vistaMeteorito= new MeteoritoBusquedaView();

if (isset($_GET['action'])) {
    $action = $_GET['action'];

   
    // 1 El controlador frontal por cada acción requerida por la interfaz reencamina la solictud al controlador 
    switch ($action) {
        case 'buscar': //Completar
            //1 procesar parametros : nombre
            $nombre = $_GET['nombre'];
            $controller->buscar($nombre);
            // 2 reenviar solicitud a controlador
            $action = 'controllers/AvistamientosController.php';
        case 'calcular': //Completar
            //1 procesar parametros :tamaño y velocidad
            $tamano = $_GET['tamano'];
            $velocidad = $_GET['velocidad'];
            // 2 reenviar solicitud a controlador
            $action = 'controllers/AvistamientosController.php';
        case 'nueva accion':
            //procesar parametros
            // reenviar solicitud a controlador
    }
} else {
    // Acción por defecto
    $vistaMeteorito->render(null);
}

