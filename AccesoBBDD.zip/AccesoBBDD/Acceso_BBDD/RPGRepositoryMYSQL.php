<?php
    require './vendor/autoload.php';
    require_once 'RPGRepositoryInterface.php';
    class RPGRepositoryMySQL implements RPGRepositoryInterface {
        private $conn; // Conexión a MYSQL
        // Constructor con los parámetros de conexión
        public function __construct($servername, $dbname, $username, $password) {
            // Crear conexión
            $this->conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
            // Establecer el modo de error de PDO a excepción
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        }
        // Implementación para encontrar una quest por su nombre
        public function findQuestByName(string $name): mixed {
            /* ?????????? */
        }
        // Implementación para obtener todas las quests
        public function findAllQuests(): array {
            $sql = "SELECT * FROM quests";
            $stmt = $this->conn->query($sql);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        }
        // Implementación para obtener todos los personajes
        public function findAllCharacters(): array {
            $sql = "SELECT * FROM characters";$stmt = $this->conn->query($sql);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        }
        // Implementación para obtener las quests asociadas a un personaje por su ID
        public function findQuestsByCharacterId(int $characterId): array {
            $sql = "
            SELECT q.*
            FROM quests q
            JOIN character_quests cq ON q.id = cq.quest_id
            WHERE cq.character_id = :characterId
            ";
            $stmt = $this->conn->prepare($sql);
            $stmt->execute(['characterId' => $characterId]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        }
        // Implementación para encontrar un personaje por su nombre
        public function findCharacterByName(string $name): mixed {
            /* ?????????????? */
        }
    }
?>