<?php
    require_once 'Acceso_BBDD/RPGRepositoryInterface.php';
    require_once 'Acceso_BBDD/RPGRepositoryMYSQL.php';
    try {
        // Crear una instancia del repositorio
        $repository = new RPGRepositoryMYSQL("mysql","rpg_game","root","1234");
        echo (" <h1>Información del juego : LISTA DE PERSONAJES Y LISTA DE DESAFIOS:</h1>");
        // Mostrar todos los personajes
        $characters = $repository->findAllCharacters();
        echo " <h3>Lista de personajes del juego: </h3>";
        foreach ($characters as $character) {
            echo ($character['name']);
            echo " ------\n"; // Separador entre personajes
        }
        //Mostrar todas las quests/desafios
        $quests = $repository->findAllQuests();
        echo " <h3>Lista de desafios del juego: </h3>";
        foreach ($quests as $quest) {
            echo ($quest['title']);
            echo " ------\n"; // Separador entre desafios
        }
    }
     catch (PDOException $e) {
        echo 'Error de conexión: ' . $e->getMessage();
    }
?>